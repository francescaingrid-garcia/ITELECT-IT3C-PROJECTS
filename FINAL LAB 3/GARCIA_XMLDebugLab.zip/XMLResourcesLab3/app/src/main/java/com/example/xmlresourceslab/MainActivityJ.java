package com.example.xmlresourceslab;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivityJ extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i("DEBUG_TAG", "MainActivity started successfully");
        Log.d("DEBUG_TAG", "Debugging message");
        Log.w("DEBUG_TAG", "Warning message");
        Log.e("DEBUG_TAG", "Error message");

    }
}

